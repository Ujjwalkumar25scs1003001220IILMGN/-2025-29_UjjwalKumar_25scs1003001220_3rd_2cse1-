import pandas as pd
df = pd.read_csv("data/agribusiness_performance.csv")
df["Total_Cost_INR"] = df["Input_Cost_INR"] + df["Logistics_Cost_INR"]
print(df.describe())
print("\nKPI Summary")
print("Average yield:", df["Yield_t_per_ha"].mean())
print("Average wastage:", df["Wastage_pct"].mean())
print("Average lead time:", df["Lead_Time_days"].mean())
print("On-time delivery:", df["On_Time_Delivery_pct"].mean())
print("ROI %:", df["Profit_INR"].sum()/df["Total_Cost_INR"].sum()*100)
print("\nCrop performance")
print(df.groupby("Crop")[["Yield_t_per_ha","Wastage_pct","Profit_INR"]].mean().sort_values("Profit_INR", ascending=False))
print("\nRegion performance")
print(df.groupby("Region")[["Wastage_pct","Lead_Time_days","On_Time_Delivery_pct"]].mean())
