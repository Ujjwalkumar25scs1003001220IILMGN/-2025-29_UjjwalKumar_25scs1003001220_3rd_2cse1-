import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt

st.set_page_config(page_title="AgriPulse Performance Dashboard", layout="wide")
st.title("AgriPulse — Agribusiness Performance Dashboard")
df = pd.read_csv("data/agribusiness_performance.csv")

crop_filter = st.sidebar.multiselect("Crop", sorted(df["Crop"].unique()), default=sorted(df["Crop"].unique()))
region_filter = st.sidebar.multiselect("Region", sorted(df["Region"].unique()), default=sorted(df["Region"].unique()))
f = df[df["Crop"].isin(crop_filter) & df["Region"].isin(region_filter)]

revenue=f["Revenue_INR"].sum()
cost=(f["Input_Cost_INR"]+f["Logistics_Cost_INR"]).sum()
profit=f["Profit_INR"].sum()
roi=profit/cost*100 if cost else 0

c1,c2,c3,c4=st.columns(4)
c1.metric("Revenue", f"₹{revenue/1e6:.2f}M")
c2.metric("Profit", f"₹{profit/1e6:.2f}M")
c3.metric("ROI", f"{roi:.1f}%")
c4.metric("Avg Wastage", f"{f['Wastage_pct'].mean():.1f}%")

st.subheader("Monthly Profit Trend")
m=f.groupby("Month")["Profit_INR"].sum()/1e6
st.line_chart(m)

st.subheader("Yield by Crop")
y=f.groupby("Crop")["Yield_t_per_ha"].mean()
st.bar_chart(y)

st.subheader("Operational Indicators")
st.dataframe(f[["Month","Region","Crop","Yield_t_per_ha","Wastage_pct","Lead_Time_days","On_Time_Delivery_pct","Profit_INR"]], use_container_width=True)
