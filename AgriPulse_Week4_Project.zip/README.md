# AgriPulse — Agribusiness Performance Evaluation & Process Improvement

## Project Overview
AgriPulse is a data analytics project that evaluates agribusiness operational performance using crop, cost, logistics, delivery and profitability indicators. The dataset is simulated and reproducible, making the project suitable for an academic internship submission and GitHub portfolio.

## KPIs
- Yield (tonnes/hectare)
- Revenue and profit
- Input and logistics cost
- ROI
- Wastage percentage
- Logistics lead time
- On-time delivery percentage

## Key Findings
- Total production: 5,449.7 tonnes
- Total revenue: ₹140.49 million
- Total operating cost: ₹89.23 million
- Total profit: ₹51.25 million
- Average yield: 3.62 t/ha
- Average wastage: 7.68%
- Average lead time: 6.03 days
- On-time delivery: 87.13%
- ROI: 57.43%

## Recommendations
1. Introduce batch-level inventory and wastage tracking.
2. Use demand forecasting to improve market responsiveness.
3. Set regional logistics alerts for high lead-time routes.
4. Monitor crop yield against input cost at farm/plot level.
5. Build a monthly KPI review dashboard.

## Run
```bash
pip install pandas numpy matplotlib streamlit
streamlit run dashboard.py
```
